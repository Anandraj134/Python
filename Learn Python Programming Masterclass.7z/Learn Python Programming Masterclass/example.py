import random

help(random.randint)
