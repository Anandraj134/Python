parrot = "Norwegian Blue"

for character in parrot:
    print(character)
