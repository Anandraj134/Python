for i in range(10, 0, -2):
    print("i is now {}".format(i))
