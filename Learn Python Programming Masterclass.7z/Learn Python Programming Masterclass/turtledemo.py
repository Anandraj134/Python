from turtle import *

done = "Well done, you have finished your drawing"

forward(150)
right(250)
forward(150)
circle(75)

done()
print(done)
