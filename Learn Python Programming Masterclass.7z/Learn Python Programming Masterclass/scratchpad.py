a = 2
b = 3
print("a is {}, b is {}".format(a, b))

a, b = 3, 2  # b, a
# temp = a
# a = b
# b = temp
print("a is {}, b is {}".format(a, b))
