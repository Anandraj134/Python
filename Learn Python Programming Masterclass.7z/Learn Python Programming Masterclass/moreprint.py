name = "Tim"
age = 10

print(name, age, "Python", 2020)
print((name, age, "Python", 2020))
