age = int(input("How old are you? "))

if age >= 16 and age <= 65:
    print("Have a good day at work")
